Une annexe disponible sur le CI-SIS indique la correspondance entre les
données d'en-tête d'un document CDA définies dans le volet structuration
minimale des documents de Santé et les métadonnées XDS définies dans le
volet partage de documents de Santé.

-   **[Annexe -- Lien Entre l'en-tête CDA et les métadonnées XDS](https://esante.gouv.fr/annexe-lien-entre-len-tete-cda-et-les-metadonnees-xds)**