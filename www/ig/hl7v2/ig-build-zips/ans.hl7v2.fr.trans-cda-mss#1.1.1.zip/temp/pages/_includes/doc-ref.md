
Liste des documents de référence :

1. [ANS - CI_SIS : Volet Echange des Documents de Santé version 1.8 et supérieure](https://esante.gouv.fr/volet-echange-de-documents-de-sante)
2. [ANS - CI_SIS : Volet Partage de documents de santé version 1.15 et supérieure](https://esante.gouv.fr/volet-partage-de-documents-de-sante)
3. [ANS - CI-SIS : CONTENU_VOLET-STRUCTURATION-MINIMALE version 1.15 et supérieure](https://esante.gouv.fr/volet-structuration-minimale-de-documents-de-sante)
4. [ANS - MSSANTE : Référentiel socle MSSanté #2 version 1.0.1 et supérieure](https://esante.gouv.fr/espace_documentation/mssante-clients-de-messageries-securisees-de-sante/referentiel-socle-mssante-2)
5. [Annexe CI-SIS : Prise en charge de l'identifiant National de Santé (INS) dans les standards d'interopérabilité et les volets du CI-SIS. version 1.5 et supérieure](https://esante.gouv.fr/annexe-prise-en-charge-de-lins-dans-les-volets-du-ci-sis)
6. [ANS - INS : Corpus Documentaire disponible sur le site de l'ANS](https://esante.gouv.fr/produits-services/referentiel-ins)
7. [ANS - CI-SIS : ANNEXE - LIEN ENTRE L'EN-TETE CDA ET LES METADONNEES XDS version 1.6 et supérieure](https://esante.gouv.fr/annexe-lien-entre-len-tete-cda-et-les-metadonnees-xds)
8. [ANS – CI_SIS : Volet Transmission de documents CDA en HL7 v2 version 2.1 et supérieure](https://esante.gouv.fr/volet-de-transmission-dun-document-cda-r2-en-hl7v2)
9. [IHE : Cadre Technique Cardiology Volumes 1,2, Révision 5.0](https://www.ihe.net/resources/technical_frameworks/)
10. [INTEROP'SANTE : ITI - PAM - National extension France - Release 2.11 et supérieure](https://www.interopsante.org/publications)
11. [INTEROP'SANTE : ITI - Contraintes sur les types de données HL7 v2.5 applicables aux profils d'intégration du cadre technique IT Infrastructure dans le périmètre d'IHE France - Release 1.8 et supérieure](https://www.interopsante.org/publications)
