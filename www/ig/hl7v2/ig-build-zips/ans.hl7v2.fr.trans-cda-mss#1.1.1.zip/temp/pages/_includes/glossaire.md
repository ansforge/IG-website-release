<table>
  <tbody>
    <tr>
      <th>
        <p>Sigle / Acronyme</p>
      </th>
      <th>
        <p>Signification</p>
      </th>
    </tr>
    <tr>
      <td>
        <p><strong>ACK :</strong></p>
      </td>
      <td>
        <p>General acknowledge message</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>BAL :</strong></p>
      </td>
      <td>
        <p>Boîte aux lettres</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>CDA-R2 :</strong></p>
      </td>
      <td>
        <p>Clinical Document Architecture Release 2</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>DPI :</strong></p>
      </td>
      <td>
        <p>Dossier Patient Informatisé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>INS :</strong></p>
      </td>
      <td>
        <p>Identité Nationale de Santé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>LPS :</strong></p>
      </td>
      <td>
        <p>Logiciel Professionnel de Santé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>MDM :</strong></p>
      </td>
      <td>
        <p>Médical Document Management</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>MLLP :</strong></p>
      </td>
      <td>
        <p>Minimal Lower Layer Protocol</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>MSSanté :</strong></p>
      </td>
      <td>
        <p>Messagerie Sécurisée de Santé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>NOS :</strong></p>
      </td>
      <td>
        <p>Nomenclature des Objets de Santé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>PFI :</strong></p>
      </td>
      <td>
        <p>Plateforme Intermédiation</p>
      </td>
    </tr>
  </tbody>
</table>