L'implementation guide contient un package [téléchargeable ici](package.tgz) permettant de valider les instances par rapport aux profils qu'il contient.

Ensemble des ressources téléchargeables :

* [L'ensemble de la specification (zip)](full-ig.zip)
* [Package (tgz)](package.tgz)

### Exemples

Les exemples sont disponibles sur github [ici](https://github.com/ansforge/hl7V2-exemples).
