### Cas d'usage
{% include cas-usage.md %}

### Organisation du contexte métier
{% include contexte-metier.md %}

### Acteurs et transactions
{% include acteurs-transactions.md %}

### Définition des processus collaboratifs
{% include def-proc-collab.md %}

### Identification des flux
{% include identification-flux.md %}