<table>
  <tbody>
    <tr>
      <th>
        <p>Sigle / Acronyme</p>
      </th>
      <th>
        <p>Signification</p>
      </th>
    </tr>
    <tr>
      <td>
        <p><strong>ACK :</strong></p>
      </td>
      <td>
        <p>General acknowledge message</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>BAL :</strong></p>
      </td>
      <td>
        <p>Boîte aux lettres</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>CDA-R2 :</strong></p>
      </td>
      <td>
        <p>Clinical Document Architecture Release 2</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>DPI :</strong></p>
      </td>
      <td>
        <p>Dossier Patient Informatisé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>DMP :</strong></p>
      </td>
      <td>
        <p>Dossier Médical Partagé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>DRIM-M :</strong></p>
      </td>
      <td>
        <p>Data Radiologie Imagerie Médicale et Médecine Nucléaire</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>INS</strong></p>
      </td>
      <td>
        <p>Identité Nationale de Santé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>MDM :</strong></p>
      </td>
      <td>
        <p>Médical Document Management</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>MLLP :</strong></p>
      </td>
      <td>
        <p>Minimal Lower Layer Protocol</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>MSSanté :</strong></p>
      </td>
      <td>
        <p>Messagerie Sécurisée de Santé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>NOS :</strong></p>
      </td>
      <td>
        <p>Nomenclature des Objets de Santé</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>ORU :</strong></p>
      </td>
      <td>
        <p>Unsolicited transmission of an Observation Message</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>PFI :</strong></p>
      </td>
      <td>
        <p>Plateforme Intermédiation</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>RIS :</strong></p>
      </td>
      <td>
        <p>Radiology information System</p>
      </td>
    </tr>
    <tr>
      <td>
        <p><strong>SGL :</strong></p>
      </td>
      <td>
        <p>Système de Gestion de Laboratoire</p>
      </td>
    </tr>
  </tbody>
</table>