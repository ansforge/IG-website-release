
<div class="figure" style='text-align: center;'>
    <img src="image16.png" alt="Figure 12" title="Figure 12 : Identification des flux" style="width:80%;">
    <figcaption><b>Figure 12 : Identification des flux</b></figcaption>
</div>    
<br>