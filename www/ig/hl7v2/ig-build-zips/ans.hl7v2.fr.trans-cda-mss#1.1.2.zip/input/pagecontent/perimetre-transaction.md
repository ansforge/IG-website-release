Le périmètre des spécifications s’applique à toute demande de transmission initiale/remplacement/suppression d’un document CDA-R2, provenant d’un courriel MSSanté réceptionné dans une BAL applicative et traité par la PFI de l’établissement hospitalier, accompagnée des informations du courriel et des métadonnées MSSanté associées au document. Ces informations sont encodées dans un flux HL7v2.6 MDM.

Les spécifications couvrent également l’accusé de réception du message HL7 MDM.

L’accusé de réception du message HL7 MDM rend compte de la bonne ou mauvaise intégration du message et des informations portées par le message au niveau de l’acteur CONSOMMATEUR.
