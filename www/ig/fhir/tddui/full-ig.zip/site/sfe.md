# Volume 1 - Etude fonctionnelle - Médicosocial - Transfert de données DUI v2.2.0

* [**Table of Contents**](toc.md)
* **Volume 1 - Etude fonctionnelle**

## Volume 1 - Etude fonctionnelle

* [Cas d'usage](sfe_cas_usage.md)
* [Organisation du contexte métier](sfe_organisation_contexte_metier.md)
* [Transmission des données à un tiers](sfe_transfert_des_donnees_a_un_tiers.md)
* [Modélisation du contenu du DUI](sfe_modelisation_contenu.md)

