# Exemple de ressource Binary - Fichier PDF - Partage de Documents de Santé en mobilité (PDSm) v3.1.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Exemple de ressource Binary - Fichier PDF**

## Example Binary: Exemple de ressource Binary - Fichier PDF

[The Content Type 'application/pdf' is not rendered in this context]



## Resource Binary Content

application/pdf:

```
{snip}
```
